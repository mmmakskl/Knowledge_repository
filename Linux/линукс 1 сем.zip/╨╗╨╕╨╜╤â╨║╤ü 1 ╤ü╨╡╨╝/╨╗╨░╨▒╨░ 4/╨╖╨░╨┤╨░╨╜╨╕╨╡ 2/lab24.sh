#!/bin/sh
if [ $# -ne 1 ] ;
	then
	echo "Please, enter the path to the file"
elif [ -f "/Users/anna/Desktop/$1" ] ; 
	then
	echo "File is real"
else
	echo "File isn't real"
fi

