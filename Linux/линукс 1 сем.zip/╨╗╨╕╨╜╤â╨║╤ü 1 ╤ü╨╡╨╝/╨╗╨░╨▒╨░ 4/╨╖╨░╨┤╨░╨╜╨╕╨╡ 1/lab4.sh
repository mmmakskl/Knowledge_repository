#!/bin/sh
res=$1
flag=1
shift 1
while [ $# -gt 1 ]
do
    if [[ $2 =~ ^[0-9]+([.][0-9]+)*$  &&  $res =~ ^[0-9]+([.][0-9]+)*$ ]]  ;
    then
        case $1 in
            "+") res=$(echo "scale=6; $res + $2" | bc) ;;
            "-") res=$(echo "scale=6; $res - $2" | bc) ;;
            "x"|"X") res=$(echo "scale=6; $res * $2" | bc) ;;
            "/")
            num2=$(echo $2 | sed 's/0.//')
            if [ $num2 -ne 0 ] ;
            then
                res=$(echo "scale=6; $res / $2" | bc)
            else
                echo "You cannot divide by 0!"
                flag=0
                break
            fi ;;
            *) echo "You cannot use this operator! Valid operators: +, -, /, x, X"
            flag=0
            break ;;
        esac
        shift 2
    else
        echo "Use only numbers"
        flag=0
        break
    fi
    done

if [ $flag -eq 1 ] ;
then
	echo "Result: $res"
fi
