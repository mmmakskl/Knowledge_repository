#!/bin/sh
tail -n +$1 z3 | head -n $2
