#!/bin/sh

file=$1

fipa=("-fipa-modref"
      "-fipa-profile"
      "-fipa-pure-const"
      "-fipa-reference"
      "-fipa-reference-addressable"
      "-fipa-bit-cp"
      "-fipa-cp"
      "-fipa-icf"
      "-fipa-ra"
      "-fipa-sra"
      "-fipa-vrp"
)

fprofile=("-fprofile-generate"
           "-fprofile-use"
)

compile() {
    option=$1
    echo "Текущие опции оптимизации: -O2 $option \n"
    g++ -Wall -O2 $opt -lm $file -o main
    echo "Время выполнения:"
    /usr/bin/time -p ./main
    echo "\n"
    echo "Размер исполняемого файла:"
    du -h ./main | cut -f1
    echo "----------------------------------------------------"
    
    echo "Текущие опции оптимизации: -O2 $option -flto\n"
    g++ -Wall -O2 $opt -flto -lm $file -o main
    echo "Время выполнения:"
    /usr/bin/time -p ./main
    echo "\n"
    echo "Размер исполняемого файла:"
    du -h ./main | cut -f1
    echo "----------------------------------------------------"
    
    echo "Текущие опции оптимизации: -O2 $option -flto -fprofile-generate\n"
    g++ -Wall -O2 $opt -flto ${fprofile[0]} -lm $file -o main
    echo "Время выполнения:"
    /usr/bin/time -p ./main
    echo "\n"
    echo "Размер исполняемого файла:"
    du -h ./main | cut -f1
    echo "----------------------------------------------------"
    
    echo "Текущие опции оптимизации: -O2 $option -flto --fprofile-use\n"
    g++ -Wall -O2 $opt -flto ${fprofile[1]} -lm $file -o main
    echo "Время выполнения:"
    /usr/bin/time -p ./main
    echo "\n"
    echo "Размер исполняемого файла:"
    du -h ./main | cut -f1
    echo "===================================================="
}

if [ -f $file ] ;
then
    echo "Исходный файл найден: $file \n"
    
    for opt in "${fipa[@]}"
    do
        compile "$opt"
    done
    
else
    echo "Исходный файл не найден: $file \n"
    exit 1
fi
