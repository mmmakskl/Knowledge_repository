#!/bin/sh
name=$1
if [ ! "$name" ] ;
then
    echo "введите название фала"
    exit 1
fi

Keys=("-O0"
      "-Os"
      "-O1"
      "-O2"
      "-O3")


for opt in ${Keys[@]} ;
do
    echo "компиляция программы с ключом оптимизации $opt "
    g++ -Wall "$opt" -lm "$name" -o main
    echo "время выполнения программы:"
    /usr/bin/time -p ./main
    echo "занимаемое исполняемым файлом дисковое пространство:"
    du -h main
    if [ "$opt" = "-O2" || "$opt" = "-O3" ] ;
    then
        echo "компиляция программы с ключом оптимизации $opt -march=native"
        g++ -Wall "$opt" -march=native -lm "$name" -o main
        echo "время выполнения программы:"
        /usr/bin/time -p ./main
        echo "занимаемое исполняемым файлом дисковое пространство:"
        du -h main
        echo "компиляция программы с ключом оптимизации $opt "
        g++ -Wall "$opt" -march=native -funroll-loops -lm "$name" -o main
        echo "время выполнения программы:"
        /usr/bin/time -p ./main
        echo "занимаемое исполняемым файлом дисковое пространство: -march=native -funroll-loops"
        du -h main
    fi
done
    


