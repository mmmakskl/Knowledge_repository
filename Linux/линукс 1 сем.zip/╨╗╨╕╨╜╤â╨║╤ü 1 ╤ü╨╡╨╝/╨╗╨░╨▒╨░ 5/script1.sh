#!/bin/sh

file=$1

optimization_keys=(
    "-O0"
    "-Os"
    "-O1"
    "-O2"
    "-O3"
    "-O2 -march=native"
    "-O3 -march=native"
    "-O2 -march=native -funroll-loops"
    "-O3 -march=native -funroll-loops"
)

compile() {
    option=$1
    echo "Текущие опции оптимизации: $option \n"
    g++ -Wall $opt -lm $file -o main
    echo "Время выполнения:"
    /usr/bin/time -p ./main
    echo "\n"
    echo "Размер исполняемого файла:"
    du -h ./main | cut -f1
    echo "----------------------------------------------------"
}

if [ -f $file ] ;
then
    echo "Исходный файл найден: $file \n"
    
    for opt in "${optimization_keys[@]}"
    do
        compile "$opt"
    done
    
else
    echo "Исходный файл не найден: $file \n"
    exit 1
fi

