#include <cmath>
int main()
{
    long long num = 0;
    for (long long i = 0; i < 10000; i++)
    {
	for (long long j = 0; j < 10000; j++)
	{
            num += pow(num, i);
	}
    }
    return num;
}
