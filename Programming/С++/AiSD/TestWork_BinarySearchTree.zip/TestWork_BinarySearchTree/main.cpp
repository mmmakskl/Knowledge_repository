#include "BinarySearchTree.hpp"

int main()
{
	test();
	return 0;
}