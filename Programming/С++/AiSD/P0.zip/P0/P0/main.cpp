//
//  main.cpp
//  P0
//
//  Created by Анна Резникова on 20.10.2023.
//

#include <iostream>

 int main()
 {
   std::cout << "reznikova.anna\n";
   return 0;
 }
