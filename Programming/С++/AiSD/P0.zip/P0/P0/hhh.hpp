//
//  hhh.hpp
//  P0
//
//  Created by Анна Резникова on 20.10.2023.
//

#ifndef hhh_hpp
#define hhh_hpp

#include <stdio.h>

#endif /* hhh_hpp */
