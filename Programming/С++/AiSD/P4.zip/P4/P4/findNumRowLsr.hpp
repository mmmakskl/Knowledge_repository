#ifndef FINDNUMROWLSR_hpp
#define FINDNUMROWLSR_hpp
#include <iosfwd>

namespace reznikova
{
  size_t findNumRowLsr(const int * matrix, size_t rows, size_t cols);
}

#endif
