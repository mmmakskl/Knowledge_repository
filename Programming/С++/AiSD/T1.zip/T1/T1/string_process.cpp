#include "string_process.hpp"
#include <iostream>
#include <string>
#include "base-types.hpp"

//double reznikova::getNextValue(std::string& line)
//{
//  size_t ptr = 0;
//  double value = std::stod(line, &ptr);
//  line = line.substr(ptr);
//  return value;
//}
//
//reznikova::point_t reznikova::getPointFromString(std::string& line)
//{
//  size_t fir_ptr = 0;
//  size_t sec_ptr = 0;
//  double x = std::stod(line, &fir_ptr);
//  line = line.substr(fir_ptr);
//  double y = std::stod(line, &sec_ptr);
//  line = line.substr(sec_ptr);
//  point_t point{x, y};
//  return point;
//}

double reznikova::getNextValue(std::string& line, int & counter)
{
  char array[255] = {0};
  strcpy(array, line.c_str());
  while (array[counter] != ' ')
  {
    value[counter] = array[counter];
    counter++;
  }
  value[counter] = '\0';
  counter++;
  std::cout << atof(value) << " ";
  return atof(value);
}

reznikova::point_t reznikova::getPointFromString(std::string& line, int & counter)
{
  double x = getNextValue(line, counter);
  double y = getNextValue(line, counter);
  point_t point{x ,y};
  return point;
}
