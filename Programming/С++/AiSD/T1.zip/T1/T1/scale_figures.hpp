#ifndef SCALE_FIGURES_HPP
#define SCALE_FIGURES_HPP
#include <iostream>
#include "shape.hpp"

namespace reznikova
{
  void scaleFigures(Shape ** figures, const int stored, std::string& line, int & counter);
}

#endif
