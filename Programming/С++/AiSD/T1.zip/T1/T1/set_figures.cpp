#include "set_figures.hpp"
#include <iostream>
#include <string>
#include <exception>
#include "base-types.hpp"
#include "shape.hpp"
#include "rectangle.hpp"
#include "ring.hpp"
#include "regular.hpp"
#include "string_process.hpp"

reznikova::Shape * reznikova::setRectangle(std::string& line, bool & ifNoErrors, int & counter)
{
  point_t leftpoint = getPointFromString(line, counter);
  point_t rightpoint = getPointFromString(line, counter);
  Shape * rectangle = nullptr;
  try
  {
    rectangle = new Rectangle(leftpoint, rightpoint);
  }
  catch (const std::runtime_error &e)
  {
    std::cerr << e.what();
    ifNoErrors = 0;
  }
  return rectangle;
}

reznikova::Shape * reznikova::setRing(std::string& line, bool & ifNoErrors, int & counter)
{
  point_t center = getPointFromString(line, counter);
  double big_rad = getNextValue(line, counter);
  double small_rad = getNextValue(line, counter);
  Shape * ring = nullptr;
  try
  {
    ring = new Ring(center, big_rad, small_rad);
  }
  catch (const std::runtime_error &e)
  {
    std::cerr << e.what();
    ifNoErrors = 0;
  }
  return ring;
}

reznikova::Shape * reznikova::setRegular(std::string& line, bool & ifNoErrors, int & counter)
{
  point_t center = getPointFromString(line, counter);
  point_t pointA = getPointFromString(line, counter);
  point_t pointB = getPointFromString(line, counter);
  Shape * regular = nullptr;
  try
  {
    regular = new Regular(center, pointA, pointB);
  }
  catch (const std::runtime_error &e)
  {
    std::cerr << e.what();
    ifNoErrors = 0;
  }
  return regular;
}

