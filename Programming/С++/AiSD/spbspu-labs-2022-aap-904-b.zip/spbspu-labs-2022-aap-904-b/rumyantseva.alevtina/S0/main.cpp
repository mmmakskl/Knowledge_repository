#include <iostream>

int main()
{
  std::cout << "rumyantseva.alevtina" << std::endl;
  return 0;
}
