#include "InputCheckAndCountControl.h"
#include <iostream>
#include <limits>

void tsherbinina::inputFirstNumber(int& maxNumber)
{
  if (!(std::cin >> maxNumber)) {
    throw std::invalid_argument("Array must contain only integers from \"-2147483648\" to \"2147483647\"!");
  }
  if (maxNumber == 0) {
    throw std::logic_error("Array mustn't be empty!");
  }
}

void tsherbinina::inputActualNumber(int& actualNumber)
{
  if (!(std::cin >> actualNumber)) {
    throw std::invalid_argument("Array must contain only integers from \"-2147483648\" to \"2147483647\"!");
  }
}

const unsigned MAX_COUNTER = std::numeric_limits<unsigned>::max();

void tsherbinina::countControl(int& maxNumber, int& actualNumber, unsigned& counter)
{
  if (actualNumber != 0) {
    if (actualNumber > maxNumber) {
      counter = 0;
      maxNumber = actualNumber;
    }
    else if (counter == MAX_COUNTER) {
      throw std::overflow_error("Array contains too many numbers!");
    }
    else {
      counter++;
    }
  }
}
