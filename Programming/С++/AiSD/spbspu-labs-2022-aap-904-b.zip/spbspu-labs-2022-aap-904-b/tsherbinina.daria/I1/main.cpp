#include <iostream>
#include "InputCheckAndCountControl.h"

int main()
{
  std::cout << "This programm counts amount of numbers after the first maximum in array." << std::endl;
  std::cout << "Enter an array number by number and end it with zero:" << std::endl;

  int maxNumber = 0;
  int actualNumber = 1;
  unsigned counter = 0;

  try {
    tsherbinina::inputFirstNumber(maxNumber);
    while (actualNumber != 0) {
      tsherbinina::inputActualNumber(actualNumber);
      tsherbinina::countControl(maxNumber, actualNumber, counter);
    }
  }
  catch (std::invalid_argument& e) {
    std::cout << "Error: " << e.what();
    return 1;
  }
  catch (std::logic_error& e) {
      std::cout << "Error: " << e.what();
      return 1;
  }
  catch (std::overflow_error& e) {
    std::cout << "Error: " << e.what();
    return 1;
  }
  std::cout << "There are " << counter << " numbers after the maximum in this array!";
  return 0;
}
