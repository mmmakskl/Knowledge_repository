#ifndef INPUT_CHECK_AND_COUNT_CONTROL_H
#define INPUT_CHECK_AND_COUNT_CONTROL_H

namespace tsherbinina {
  void inputFirstNumber(int& maxNumber);
  void inputActualNumber(int& actualNumber);
  void countControl(int& maxNumber, int& actualNumber, unsigned& counter);
}

#endif
