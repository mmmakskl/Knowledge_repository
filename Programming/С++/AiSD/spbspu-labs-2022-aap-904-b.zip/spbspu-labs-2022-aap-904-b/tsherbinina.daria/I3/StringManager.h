#ifndef STRING_MANAGER_H
#define STRING_MANAGER_H

#include <cstddef>

namespace tsherbinina {
  char* inputCheck(std::size_t& cap);
  char* stringMerger(char* source, char*& destination, std::size_t cap);
}

#endif
