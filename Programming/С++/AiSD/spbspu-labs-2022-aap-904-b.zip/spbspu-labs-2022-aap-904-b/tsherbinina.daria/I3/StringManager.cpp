#include "StringManager.h"
#include <iostream>

char* tsherbinina::inputCheck(std::size_t& cap)
{
  size_t capacity = 10;
  char* cstring = new char[capacity] {};
  std::size_t size = 0;
  std::cin >> std::noskipws;
  do {
    if (size == capacity) {
      char* temp = nullptr;
      try {
        temp = new char[capacity + 10];
      } catch (const std::bad_alloc& e) {
        delete[] cstring;
        throw std::invalid_argument("Failure to allocate storage!");
      }
      for (char *i = cstring, *j = temp; i != cstring + size; ++i, ++j) {
        *j = *i;
      }
      delete[] cstring;
      cstring = temp;
      capacity += 10;
    }
    std::cin >> cstring[size];
  } while (std::cin && cstring[size++] != '\n');
  if (!cstring[0]) {
    delete[] cstring;
    throw std::invalid_argument("String can't be empty!");
  } else {
    cstring[size - 1] = '\0';
  }
  cap += capacity;
  return cstring;
}

char* tsherbinina::stringMerger(char* source, char*& destination, std::size_t cap)
{
  try {
    destination = new char[cap];
  } catch (const std::bad_alloc& e) {
    throw std::invalid_argument("Failure to allocate storage!");
  }
  char srtConst[] = { '-','-', '-', '-', '-', '-', '-', '-', '-', '\0' };
  int i = 0;
  while (source[i] != '\0' && srtConst[i] != '\0') {
    destination[i * 2] = source[i];
    destination[i * 2 + 1] = srtConst[i];
    i++;
  }
  if (source[i] == '\0' && srtConst[i] != '\0') {
    int step = i * 2;
    while (srtConst[i] != '\0') {
      destination[step] = srtConst[i];
      step++, i++;
    }
    destination[step] = '\0';
  } else if (source[i] != '\0' && srtConst[i] == '\0') {
    int step = i * 2;
    while (source[i] != '\0') {
      destination[step] = source[i];
      step++, i++;
    }
    destination[step] = '\0';
  } else {
    destination[i * 2] = '\0';
  }
  return destination;
}
