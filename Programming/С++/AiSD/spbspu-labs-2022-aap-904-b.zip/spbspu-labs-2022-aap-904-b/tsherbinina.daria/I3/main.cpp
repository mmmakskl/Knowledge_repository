#include <iostream>
#include <cstddef>
#include "StringManager.h"

int main()
{
  std::cout << " This program merges two strings by alternating their elements! \n";
  std::cout << " Enter string: \n";
  std::size_t strCap = 10;
  char* strIn = nullptr;
  char* strOut = nullptr;
  try {
    strIn = tsherbinina::inputCheck(strCap);
    tsherbinina::stringMerger(strIn, strOut, strCap);
  } catch (std::invalid_argument& e) {
    std::cout << " Error: " << e.what();
    return 1;
  }
  std::cout << " Resulting string is \"" << strOut << "\" ! \n";
  delete[] strIn;
  delete[] strOut;
}
