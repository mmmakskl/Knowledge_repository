#include <iostream>
#include "StructArray.h"

int main (int argc, char* argv[])
{
  if (argc != 2) {
    std::cerr << " Error: Not enough or too many arguments! \n";
    return 1;
  }
  std::cout << " This program counts the sum of indixes of min and max elements! \n";
  int sample[] = { 2, 4, 6, 8, 10, 9, 7, 5, 3, 1 };
  tsherbinina::Array constArray(10);
  for (int i = 0; i < 10; i++) {
    constArray.sequence[i] = sample[i];
  }
  const char* path = argv[1];
  int crutch = 0;
  try {
    tsherbinina::Array fileArray(path);
    crutch = fileArray.indexSumCounter();
  } catch (std::invalid_argument& e) {
    std::cout << " Error: " << e.what();
    return 1;
  }
  std::cout << " Enter the size of dynamic array: \n";
  std::size_t size;
  std::cin >> size;
  if (std::cin.fail()) {
    std::cerr << " Error: Incorrect size of dynamic array! \n";
    return 1;
  }
  if (size <= 0) {
    return 0;
  }
  tsherbinina::Array dynamicArray(size);
  try {
    std::cout << " The sum of indixes in const array is \"" << constArray.indexSumCounter() << "\" ! \n";
    std::cout << " The sum of indixes in dynamic array is \"" << dynamicArray.indexSumCounter() << "\" ! \n";
  } catch (std::invalid_argument& e) {
    std::cout << " Error: " << e.what();
    return 1;
  }
  std::cout << " The sum of indixes in file array is \"" << crutch << "\" ! \n";
}
