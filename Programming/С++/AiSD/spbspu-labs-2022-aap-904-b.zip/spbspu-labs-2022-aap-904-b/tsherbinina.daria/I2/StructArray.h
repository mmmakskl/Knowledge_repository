#ifndef STRUCT_ARRAY_H
#define STRUCT_ARRAY_H

#include <cstddef>

namespace tsherbinina {
  struct Array
  {
    int* sequence;
    std::size_t capacity;

    Array();
    Array(std::size_t);
    Array(const char*);

    ~Array();

    int indexSumCounter();
  };
}

#endif
