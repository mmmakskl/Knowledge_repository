#include "StructArray.h"
#include <iostream>
#include <fstream>
#include <cstddef>

tsherbinina::Array::Array():
  sequence(nullptr),
  capacity(0)
{}

tsherbinina::Array::Array(std::size_t cap):
  sequence(new int[cap]),
  capacity(cap)
{
  for (std::size_t i = 0; i < cap; i++) {
    sequence[i] = rand();
  }
}

tsherbinina::Array::Array(const char* path)
{
  std::ifstream fileArray(path, std::ios_base::in);
  if (!fileArray.is_open()) {
    throw std::invalid_argument(" File can't be opened! ");
  }
  fileArray >> capacity;
  if (fileArray.fail()) {
    throw std::invalid_argument(" Incorrect capacity of file array! ");
  }
  sequence = new int[capacity];
  for (int i = 0, element; !fileArray.eof(); i++) {
    fileArray >> element;
    sequence[i] = element;
    if (fileArray.fail()) {
      throw std::invalid_argument(" Incorrect elements in file array! ");
    }
  }
  fileArray.close();
}

tsherbinina::Array::~Array()
{
  delete[] sequence;
}

int tsherbinina::Array::indexSumCounter()
{
  if (capacity < 2) {
    return 1;
  }
  int maxIndex = 1;
  int minIndex = 1;
  for (std::size_t i = 0; i < capacity; i++) {
    if (sequence[i] > sequence[maxIndex - 1]) {
      maxIndex = i + 1;
    }
    if (sequence[i] < sequence[minIndex - 1]) {
      minIndex = i + 1;
    }
  }
  if (minIndex == maxIndex) {
    throw std::invalid_argument(" Array of identical elements! ");
  }
  return minIndex + maxIndex;
 }
