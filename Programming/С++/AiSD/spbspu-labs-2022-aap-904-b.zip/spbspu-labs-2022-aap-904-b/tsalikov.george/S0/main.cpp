#include <iostream>

int main()
{
    std::cout << "tsalikov.george" << std::endl;
}
