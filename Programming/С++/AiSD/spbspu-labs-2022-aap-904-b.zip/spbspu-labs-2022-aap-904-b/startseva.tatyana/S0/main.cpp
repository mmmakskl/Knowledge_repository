#include <iostream>

int main()
{
  std::cout << "startseva.tatyana" << std::endl;
  return 0;
}
