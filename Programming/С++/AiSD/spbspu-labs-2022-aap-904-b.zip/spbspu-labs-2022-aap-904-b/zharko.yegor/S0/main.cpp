#include <iostream>

int main() {
  std::cout << "zharko.yegor" << std::endl;
}
