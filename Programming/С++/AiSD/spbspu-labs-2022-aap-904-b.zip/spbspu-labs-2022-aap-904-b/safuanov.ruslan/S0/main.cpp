﻿#include <iostream>

int main()
{
  std::cout << "safuanov.ruslan" << std::endl;
  return 0;
}
