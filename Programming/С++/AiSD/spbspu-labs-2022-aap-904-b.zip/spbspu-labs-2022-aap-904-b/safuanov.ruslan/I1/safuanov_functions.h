namespace safuanov {
  int acceptInputIfNumber();
  int findLongestDecrease(int last, int next);
}
