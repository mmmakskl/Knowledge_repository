#include <iostream>
#include "safuanov_functions.h"

int main()
{
  std::cout << "Enter an integer element of the sequence:\n";
  try {
    int num = safuanov::acceptInputIfNumber();
    if (num == 0)
    {
      std::cout << "Sequence is empty.\n";
    }
    else
    {
      std::cout << safuanov::findLongestDecrease(num, safuanov::acceptInputIfNumber());
    }
  }
  catch (...) {
    std::cout << "Oops, it is error";
    return 1;
  }
  return 0;
}
