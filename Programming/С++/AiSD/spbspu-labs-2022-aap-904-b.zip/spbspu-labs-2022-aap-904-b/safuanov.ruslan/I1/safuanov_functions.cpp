#include "safuanov_functions.h"
#include <iostream>

int safuanov::acceptInputIfNumber()
{
  int number;
  if (!(std::cin >> number))
  {
    throw std::invalid_argument("Error, you must enter an integer not larger than 2 147 483 647.\n");
  }
  return number;
}

int safuanov::findLongestDecrease(int last, int next)
{
  int counter = 1;
  int max_counter = 1;
  while (next != 0) {
    if (next < last)
    {
      counter = counter + 1;
    }
    else
    {
      counter = 1;
    }
    if (counter > max_counter)
    {
      max_counter = counter;
    }
    last = next;
    next = safuanov::acceptInputIfNumber();
  }
  return max_counter;
}
