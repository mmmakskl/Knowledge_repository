#ifndef INPUT_DATA_H
#define INPUT_DATA_H

namespace ponomarev {
  int inputElement();
}

#endif
