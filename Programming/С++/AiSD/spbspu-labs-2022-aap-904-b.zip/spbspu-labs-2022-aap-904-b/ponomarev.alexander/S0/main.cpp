#include <iostream>

int main()
{
  std::cout << "ponomarev.alexander\n";
  return 0;
}
