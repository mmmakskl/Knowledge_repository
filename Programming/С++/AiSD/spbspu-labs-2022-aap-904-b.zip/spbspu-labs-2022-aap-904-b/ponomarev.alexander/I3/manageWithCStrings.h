#ifndef MANAGE_WITH_C_STRING_H
#define MANAGE_WITH_C_STRING_H

#include <cstddef>

namespace ponomarev {
  char *removeAlpha(char *destination, char *source);
}

#endif
