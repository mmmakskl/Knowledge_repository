#ifndef INPUT_AND_MAX_COUNTING_FUNCTIONS_H
#define INPUT_AND_MAX_COUNTING_FUNCTIONS_H

namespace ponomarev {
  void changeMax(int &maxNumber, int &nMax, bool &isFirstInput, int inputNumber);
  int inputElement();
}

#endif
