#include <iostream>

int main()
{
    std::cout<<"siobko.boris\n";
}
