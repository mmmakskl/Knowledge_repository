#ifndef LOGIC_H
#define LOGIC_H
namespace siobko
{
  void check_NumIfIsFloat(double &dblnum);
  int enter_num();
  void check_overflow(int &sum, int &summand);
}
#endif
