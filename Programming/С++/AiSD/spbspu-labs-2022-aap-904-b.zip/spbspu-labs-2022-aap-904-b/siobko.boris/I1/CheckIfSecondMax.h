﻿#ifndef CheckIfSecondMax_H
#define CheckIfSecondMax_H
namespace siobko
{
  bool ResultOfCondition(int num1, int num2, int num3);
  struct CheckIfSecondMax
  {
    bool operator()(int num1, int num2, int num3);
  };
}
#endif
