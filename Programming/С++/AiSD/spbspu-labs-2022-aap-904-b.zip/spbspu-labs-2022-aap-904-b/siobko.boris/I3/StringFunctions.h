﻿#ifndef STRING_FUNCTIONS
#define STRING_FUNCTIONS
#include <cstddef>
namespace siobko
{
  unsigned short CountDiffLetters(char *str);
  bool IsCharEnglishLetter(char letter);
}
#endif
