﻿#ifndef ManageArrays_H
#define ManageArrays_H
#include <cstddef>
namespace siobko
{
  void ManageWithArrays(const size_t ShiftCount, const char* FILENAME, size_t SIZE_DYN_ARRAY);
}
#endif
