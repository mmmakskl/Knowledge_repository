#include <iostream>

 int main()
 {
   std::cout << "flusova.sofia" << std::endl;
   return 0;
 }
