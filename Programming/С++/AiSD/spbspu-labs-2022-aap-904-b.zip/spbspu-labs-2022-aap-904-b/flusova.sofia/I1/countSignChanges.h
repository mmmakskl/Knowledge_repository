#ifndef COUNT_SIGN_CHANGES_H
#define COUNT_SIGN_CHANGES_H

namespace flusova {
  int checkInput();
  bool checkSign(int &num, int &yaNum);
  int checkCountNums(int &num, int &yaNum, int& counter);
}

#endif
