#ifndef INPUT_DATA_H
#define INPUT_DATA_H
#include <iostream>
#include <cstddef>

namespace flusova {
  char* inputData(std::istream &cin, size_t &capacity);
}

#endif
