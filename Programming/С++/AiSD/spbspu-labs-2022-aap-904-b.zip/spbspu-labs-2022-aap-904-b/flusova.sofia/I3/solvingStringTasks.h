#ifndef SOLVING_STRING_TASKS_H
#define SOLVING_STRING_TASKS_H
#include <cstddef>

namespace flusova
{
  bool checkSameNearElInCline(char* cstring);
  bool checkSameDigitsInCline(char* cstring);
}

#endif
