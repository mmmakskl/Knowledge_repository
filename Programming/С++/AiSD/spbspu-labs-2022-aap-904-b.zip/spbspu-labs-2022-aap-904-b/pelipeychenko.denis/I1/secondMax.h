#ifndef LAB5_SECONDMAX_H
#define LAB5_SECONDMAX_H

namespace pelipeychenko {
  int intInput(bool first_element);
  int findSecondMaxOfSubsequence();
}

#endif
