#include "CompositeShape.h"

pelipeychenko::CompositeShape::CompositeShape(const std::size_t size) :
  size_(size),
  data_(new Shape *[size_]) {}

pelipeychenko::CompositeShape::CompositeShape() :
  size_(0u),
  data_(nullptr) {}

pelipeychenko::CompositeShape::CompositeShape(const CompositeShape &instance) :
  size_(instance.size_),
  data_(new Shape *[instance.size_]) {
  for (std::size_t shape = 0; shape < size_; shape++) {
    data_[shape] = instance.data_[shape]->clone();
  }
}

pelipeychenko::CompositeShape::CompositeShape(CompositeShape &&instance) noexcept:
  size_(instance.size_),
  data_(instance.data_) {
  instance.size_ = 0u;
  instance.data_ = nullptr;
}

pelipeychenko::CompositeShape::~CompositeShape() {
  while (size_ > 0) {
    popBack();
  }
  delete[] data_;
}

rectangle_t pelipeychenko::CompositeShape::getFrameRect() const {
  if (size_ == 0) {
    return {0, 0, {0, 0}};
  }
  rectangle_t frameRect = data_[0]->getFrameRect();
  double upperY = frameRect.center_.y_ + (frameRect.height_ / 2);
  double lowerY = frameRect.center_.y_ - (frameRect.height_ / 2);
  double leftX = frameRect.center_.x_ - (frameRect.width_ / 2);
  double rightX = frameRect.center_.x_ + (frameRect.width_ / 2);
  for (std::size_t shape = 0; shape < size_; shape++) {
    frameRect = data_[shape]->getFrameRect();
    if (frameRect.center_.y_ + (frameRect.height_ / 2) > upperY) {
      upperY = frameRect.center_.y_ + (frameRect.height_ / 2);
    }
    if (frameRect.center_.y_ - (frameRect.height_ / 2) < lowerY) {
      lowerY = frameRect.center_.y_ - (frameRect.height_ / 2);
    }
    if (frameRect.center_.x_ + (frameRect.height_ / 2) > rightX) {
      rightX = frameRect.center_.x_ + (frameRect.height_ / 2);
    }
    if (frameRect.center_.x_ - (frameRect.height_ / 2) < leftX) {
      leftX = frameRect.center_.x_ - (frameRect.height_ / 2);
    }
  }
  return {rightX - leftX, upperY - lowerY,
          {(rightX + leftX) / 2, (upperY + lowerY) / 2}};
}

double pelipeychenko::CompositeShape::getArea() const {
  double area = 0;
  for (size_t shape = 0; shape < size_; shape++) {
    area += data_[shape]->getArea();
  }
  return area;
}

void pelipeychenko::CompositeShape::scale(const double factor) {
  if (factor <= 0.0) {
    throw std::invalid_argument("factor can't be non positive");
  }
  for (std::size_t shape = 0; shape < size_; ++shape) {
    data_[shape]->scale(factor);
  }
}

void pelipeychenko::CompositeShape::move(const double dX, const double dY) {
  for (std::size_t shape = 0; shape < size_; ++shape) {
    data_[shape]->move(dX, dY);
  }
}

void pelipeychenko::CompositeShape::move(const point_t &newCenter) {
  for (std::size_t shape = 0; shape < size_; ++shape) {
    data_[shape]->move(newCenter);
  }
}

pelipeychenko::CompositeShape *pelipeychenko::CompositeShape::clone() {
  return new CompositeShape(*this);
}

void pelipeychenko::CompositeShape::pushBack(Shape *newShape) {
  Shape **subData = new Shape *[size_ + 1];
  for (std::size_t shape = 0; shape < size_; ++shape) {
    subData[shape] = data_[shape];
  }
  subData[size_] = newShape->clone();
  size_++;
  delete[] data_;
  data_ = subData;
}

void pelipeychenko::CompositeShape::popBack() {
  delete data_[size_ - 1];
  data_[size_ - 1] = nullptr;
  size_--;
}

pelipeychenko::Shape *pelipeychenko::CompositeShape::at(const std::size_t index) const {
  return data_[index];
}

pelipeychenko::Shape *pelipeychenko::CompositeShape::operator[](const std::size_t index) const {
  return data_[index];
}

bool pelipeychenko::CompositeShape::empty() const {
  return (size_ == 0);
}

std::size_t pelipeychenko::CompositeShape::size() const {
  return size_;
}
