#include "shape.h"

void pelipeychenko::Shape::scale(const double factor) {
  if (factor <= 0.0) {
    throw std::invalid_argument("factor can't be non positive");
  }
  doScale(factor);
}
