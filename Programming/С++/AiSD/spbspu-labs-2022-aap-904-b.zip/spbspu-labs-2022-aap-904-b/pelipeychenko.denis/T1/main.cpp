#include <iostream>
#include "base_types.h"
#include "Polygon.h"
#include "Rectangle.h"
#include "Diamond.h"
#include "CompositeShape.h"

int main() {
  std::string name;
  std::cin >> name;
  pelipeychenko::CompositeShape composition;
  bool scaleDone = false;
  while (std::cin.peek() != EOF) {
    if (name == "POLYGON") {

      try {
        Polygon polygon;
        composition.pushBack(&polygon);
      } catch (const std::invalid_argument &e) {
        std::cerr << e.what() << "\n";
      } catch (const std::bad_alloc &e) {
        std::cerr << "bad_alloc error!" << "\n";
        return 1;
      }

    } else if (name == "RECTANGLE") {

      double leftX, lowerY, rightX, upperY;
      std::cin >> leftX >> lowerY >> rightX >> upperY;
      try {
        Rectangle rectangle({leftX, lowerY}, {rightX, upperY});
        composition.pushBack(&rectangle);
      } catch (const std::invalid_argument &e) {
        std::cerr << e.what() << "\n";
      } catch (const std::bad_alloc &e) {
        std::cerr << "bad_alloc error!" << "\n";
        return 1;
      }

    } else if (name == "DIAMOND") {

      double firstX, firstY, secondX, secondY, thirdX, thirdY;
      std::cin >> firstX >> firstY >> secondX >> secondY >> thirdX >> thirdY;
      try {
        Diamond diamond({firstX, firstY}, {secondX, secondY}, {thirdX, thirdY});
        composition.pushBack(&diamond);
      } catch (const std::invalid_argument &e) {
        std::cerr << e.what() << "\n";
      } catch (const std::bad_alloc &e) {
        std::cerr << "bad_alloc error!" << "\n";
        return 1;
      }

    } else if (name == "SCALE") {
      if (composition.empty()) {
        std::cerr << "nothing to scale" << "\n";
        return 1;
      }
      std::cout.precision(1);
      std::cout << std::fixed << composition.getArea();
      for (size_t shape = 0; shape < composition.size(); shape++) {
        rectangle_t rect = composition[shape]->getFrameRect();
        std::cout << " " << rect;
      }
      std::cout << "\n";

      double newX, newY, factor;
      std::cin >> newX >> newY >> factor;
      for (std::size_t shape = 0; shape < composition.size(); shape++) {
        double dX, dY;
        dX = (composition[shape]->getFrameRect().center_.x_ - newX) * factor;
        dY = (composition[shape]->getFrameRect().center_.y_ - newY) * factor;
        composition[shape]->move({newX, newY});
        composition[shape]->move(dX, dY);
        try {
          composition[shape]->scale(factor);
        } catch (const std::invalid_argument &e) {
          std::cerr << e.what() << "\n";
          return 1;
        }
      }

      std::cout << std::fixed << composition.getArea();
      for (size_t shape = 0; shape < composition.size(); shape++) {
        rectangle_t rect = composition[shape]->getFrameRect();
        std::cout << " " << rect;
      }
      scaleDone = true;
      std::cout << "\n";
      break;
    }
    std::cin >> name;
  }
  if (!scaleDone) {
    std::cerr << "scale was not done" << "\n";
    return 1;
  }
  return 0;
}
