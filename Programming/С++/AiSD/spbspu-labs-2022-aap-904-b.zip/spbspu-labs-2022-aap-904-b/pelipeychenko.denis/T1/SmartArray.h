#ifndef SMARTARRAY_H
#define SMARTARRAY_H

#include <cstddef>
#include <iostream>

namespace pelipeychenko {
  template < typename Data >
  class SmartArray {
  public:
    SmartArray();

    explicit SmartArray(const std::size_t &size);

    SmartArray(const SmartArray<Data> &instance);

    SmartArray<Data> &operator=(const SmartArray<Data> &instance);

    ~SmartArray();

    void inputData(bool uniqueElements = false);

    void pushBack(const Data &instance, bool uniqueElements = false);

    void popBack();

    Data *operator[](std::size_t index) const;

    bool empty() const;

    std::size_t size() const;

    SmartArray clone();

  private:
    std::size_t size_;
    Data *data_;
  };

  template < typename Data >
  SmartArray<Data>::SmartArray() :
    size_(0),
    data_(nullptr) {}

  template < typename Data >
  SmartArray<Data>::SmartArray(const std::size_t &size) :
    size_(size),
    data_(new Data[size_]) {}

  template < typename Data >
  SmartArray<Data>::SmartArray(const SmartArray<Data> &instance) :
    size_(instance.size_),
    data_(new Data[size_]) {
    for (size_t element = 0; element < size_; element++) {
      data_[element] = instance.data_[element];
    }
  }

  template < typename Data >
  SmartArray<Data> &SmartArray<Data>::operator=(const SmartArray<Data> &instance) {
    if (this == &instance) {
      return *this;
    }
    size_ = instance.size_;
    data_ = new Data[size_];
    for (size_t element = 0; element < size_; element++) {
      data_[element] = instance.data_[element];
    }
    return *this;
  }

  template < typename Data >
  SmartArray<Data>::~SmartArray() {
    delete[] data_;
  }

  template < typename Data >
  void SmartArray<Data>::inputData(const bool uniqueElements) {
    do {
      Data element;
      std::cin >> element;
      pushBack(element, uniqueElements);
    } while (std::cin && std::cin.get() != '\n');
  }

  template < typename Data >
  void SmartArray<Data>::pushBack(const Data &instance, bool uniqueElements) {
    Data *subData = new Data[size_ + 1];
    for (size_t element = 0; element < size_; ++element) {
      subData[element] = data_[element];
      if (instance == subData[element] && uniqueElements) {
        delete[] subData;
        throw std::invalid_argument("elements can't be equal");
      }
    }
    subData[size_] = instance;
    size_++;
    std::swap(subData, data_);
    delete[] subData;
  }

  template < typename Data >
  void SmartArray<Data>::popBack() {
    data_[size_ - 1] = nullptr;
    size_--;
  }

  template < typename Data >
  Data *SmartArray<Data>::operator[](const std::size_t index) const {
    return (&data_[index]);
  }

  template < typename Data >
  std::size_t SmartArray<Data>::size() const {
    return size_;
  }

  template < typename Data >
  bool SmartArray<Data>::empty() const {
    return (size_ == 0);
  }

  template < typename Data >
  SmartArray<Data> SmartArray<Data>::clone() {
    return new SmartArray(*this);
  }
}

#endif
