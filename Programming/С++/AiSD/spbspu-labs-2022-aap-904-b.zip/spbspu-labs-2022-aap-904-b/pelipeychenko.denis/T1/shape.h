#ifndef SHAPES_SHAPE_H
#define SHAPES_SHAPE_H

#include <cstddef>
#include "base_types.h"

namespace pelipeychenko {
  class Shape {
  public:
    virtual ~Shape() = default;

    virtual double getArea() const = 0;

    virtual rectangle_t getFrameRect() const = 0;

    virtual void move(const point_t &newCenter) = 0;

    virtual void move(double dX, double dY) = 0;

    void scale(double factor);

    virtual Shape *clone() = 0;

  private:
    virtual void doScale(double factor) = 0;
  };
}

#endif
