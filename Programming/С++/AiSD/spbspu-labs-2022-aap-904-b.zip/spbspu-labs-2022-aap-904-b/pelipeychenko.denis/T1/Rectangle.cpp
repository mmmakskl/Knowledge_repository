#include "Rectangle.h"
#include <iostream>

Rectangle::Rectangle(const point_t &leftLowerP, const point_t &rightUpperP) :
  center_({(leftLowerP.x_ + rightUpperP.x_) / 2,
           (leftLowerP.y_ + rightUpperP.y_) / 2}),
  width_(rightUpperP.x_ - leftLowerP.x_),
  height_(rightUpperP.y_ - leftLowerP.y_) {
  if (width_ < 0 || height_ < 0) {
    throw std::invalid_argument("Rectangle creation error");
  }
}

double Rectangle::getArea() const {
  return width_ * height_;
}

rectangle_t Rectangle::getFrameRect() const {
  return {width_, height_, center_};
}

void Rectangle::move(const point_t &newCenter) {
  center_ = newCenter;
}

void Rectangle::move(const double dX, const double dY) {
  center_.x_ += dX;
  center_.y_ += dY;
}

void Rectangle::doScale(const double factor) {
  height_ *= factor;
  width_ *= factor;
}

Rectangle *Rectangle::clone() {
  point_t leftLower{center_.x_ - (width_ / 2), center_.y_ - (height_ / 2)};
  point_t rightUpper{center_.x_ + (width_ / 2), center_.y_ + (height_ / 2)};
  return new Rectangle(leftLower, rightUpper);
}
