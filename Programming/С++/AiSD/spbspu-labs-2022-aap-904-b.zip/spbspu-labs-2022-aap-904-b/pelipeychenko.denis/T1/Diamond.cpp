#include "Diamond.h"
#include <iostream>

Diamond::Diamond(const point_t &first, const point_t &second, const point_t &third) {
  vertical_ = 2 * std::max(std::abs(first.y_ - third.y_), std::abs(second.y_ - third.y_));
  horizontal_ = 2 * std::max(std::abs(first.x_ - third.x_), std::abs(second.x_ - third.x_));
  if ((first.x_ == second.x_ && first.y_ == third.y_) || (first.x_ == third.x_ && first.y_ == second.y_)) {
    center_ = first;
  } else if ((second.x_ == third.x_ && second.y_ == first.y_) || (second.x_ == first.x_ && second.y_ == third.y_)) {
    center_ = second;
  } else if ((third.x_ == second.x_ && third.y_ == first.y_) || (third.x_ == first.x_ && third.y_ == second.y_)) {
    center_ = third;
  } else {
    throw std::invalid_argument("Diamond creation error");
  }
}

double Diamond::getArea() const {
  return vertical_ * horizontal_ / 2;
}

rectangle_t Diamond::getFrameRect() const {
  return {horizontal_, vertical_, center_};
}

void Diamond::move(const point_t &newCenter) {
  center_ = newCenter;
}

void Diamond::move(const double dX, const double dY) {
  center_.x_ += dX;
  center_.y_ += dY;
}

void Diamond::doScale(const double factor) {
  vertical_ *= factor;
  horizontal_ *= factor;
}

Diamond *Diamond::clone() {
  point_t top{center_.x_, center_.y_ + (vertical_ / 2)};
  point_t right{center_.x_ + (horizontal_ / 2), center_.y_};
  return new Diamond(center_, top, right);
}
