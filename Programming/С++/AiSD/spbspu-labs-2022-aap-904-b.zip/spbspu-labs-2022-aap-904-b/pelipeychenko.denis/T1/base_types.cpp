#include "base_types.h"

std::ostream &operator<<(std::ostream &os, const point_t &instance) {
  return os << instance.x_ << " " << instance.y_;
}

std::istream &operator>>(std::istream &is, point_t &instance) {
  return is >> instance.x_ >> instance.y_;
}

point_t operator+=(const point_t &first, const point_t &second) {
  return {first.x_ + second.x_, first.y_ + second.y_};
}

std::ostream &operator<<(std::ostream &os, rectangle_t &instance) {
  return os << instance.center_.x_ - instance.width_ * 0.5 <<
            " " << instance.center_.y_ - instance.height_ * 0.5 << " "
            << instance.center_.x_ + instance.width_ * 0.5 <<
            " " << instance.center_.y_ + instance.height_ * 0.5;
}

bool operator==(const point_t &first, const point_t &second) {
  return (first.x_ == second.x_ && first.y_ == second.y_);
}
