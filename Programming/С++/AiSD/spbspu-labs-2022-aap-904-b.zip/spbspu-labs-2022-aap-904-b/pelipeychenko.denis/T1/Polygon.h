#ifndef POLYGON_H
#define POLYGON_H

#include <cstddef>
#include "shape.h"
#include "SmartArray.h"

class Polygon: public pelipeychenko::Shape {
public:
  Polygon();

  Polygon(const Polygon &instance);

  ~Polygon() override = default;

  point_t getCentre();

  double getArea() const override;

  rectangle_t getFrameRect() const override;

  void move(double dX, double dY) override;

  void move(const point_t &newCenter) override;

  Polygon *clone() override;

private:
  pelipeychenko::SmartArray<point_t> points_;

  void doScale(double factor) override;
};

#endif
