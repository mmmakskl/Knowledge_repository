#include "Polygon.h"
#include <iostream>

Polygon::Polygon() :
  points_() {
  points_.inputData(true);
  if (points_.size() < 3) {
    throw std::invalid_argument("polygon must include 3 or more points");
  }
}

Polygon::Polygon(const Polygon &instance) {
  points_ = instance.points_;
}

point_t Polygon::getCentre() {
  double sumX = 0;
  double sumY = 0;
  for (size_t i = 0; i < points_.size(); ++i) {
    sumX += points_[i]->x_;
    sumY += points_[i]->y_;
  }
  return {sumX / points_.size(), sumY / points_.size()};
}

double Polygon::getArea() const {
  double sumX = 0;
  double sumY = 0;
  for (size_t i = 0; i < points_.size() - 1; ++i) {
    sumX += points_[i]->x_ * points_[i + 1]->y_;
    sumY += points_[i]->y_ * points_[i + 1]->x_;
  }
  sumX += points_[points_.size() - 1]->x_ * points_[0]->y_;
  sumY += points_[points_.size() - 1]->y_ * points_[0]->x_;
  return (sumY - sumX) / 2;
}

rectangle_t Polygon::getFrameRect() const {
  double upperY = points_[0]->y_;
  double lowerY = points_[0]->y_;
  double leftX = points_[0]->x_;
  double rightX = points_[0]->x_;
  for (size_t point = 0; point != (points_.size() - 1); point++) {
    if (points_[point]->x_ > rightX) {
      rightX = points_[point]->x_;
    } else if (points_[point]->x_ < leftX) {
      leftX = (points_[point]->x_);
    }
    if (points_[point]->y_ < lowerY) {
      lowerY = points_[point]->y_;
    } else if (points_[point]->y_ > upperY) {
      upperY = points_[point]->y_;
    }
  }
  return {rightX - leftX, upperY - lowerY,
          {(rightX + leftX) / 2, (upperY + lowerY) / 2}};
}

void Polygon::move(const double dX, const double dY) {
  for (std::size_t point = 0; point < points_.size(); ++point) {
    points_[point]->x_ += dX;
    points_[point]->y_ += dY;
  }
}

void Polygon::move(const point_t &newCenter) {
  double dX = newCenter.x_ - getCentre().x_;
  double dY = newCenter.y_ - getCentre().y_;
  move(dX, dY);
}

Polygon *Polygon::clone() {
  return new Polygon(*this);
}

void Polygon::doScale(const double factor) {
  double vectorX, vectorY;
  double centreX = getCentre().x_;
  double centreY = getCentre().y_;
  for (std::size_t element = 0; element < points_.size(); ++element) {
    vectorX = points_[element]->x_ - centreX;
    vectorY = points_[element]->y_ - centreY;
    points_[element]->x_ = centreX + vectorX * factor;
    points_[element]->y_ = centreY + vectorY * factor;
  }
}
