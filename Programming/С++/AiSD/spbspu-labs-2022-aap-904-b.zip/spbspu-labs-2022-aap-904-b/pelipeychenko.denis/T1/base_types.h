#ifndef BASE_TYPES_H
#define BASE_TYPES_H

#include <iostream>

struct point_t {
  double x_, y_;
};

struct rectangle_t {
  double width_, height_;
  point_t center_;
};

std::ostream &operator<<(std::ostream &os, const point_t &instance);

point_t operator+=(point_t &first, point_t &second);

std::istream &operator>>(std::istream &is, point_t &instance);

bool operator==(const point_t &first, const point_t &second);

std::ostream &operator<<(std::ostream &os, rectangle_t &instance);

#endif
