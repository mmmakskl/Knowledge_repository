#ifndef DIAMOND_H
#define DIAMOND_H

#include "shape.h"

class Diamond: public pelipeychenko::Shape {
public:
  Diamond(const point_t &first, const point_t &second, const point_t &third);

  ~Diamond() override = default;

  double getArea() const override;

  rectangle_t getFrameRect() const override;

  void move(const point_t &newCenter) override;

  void move(double dX, double dY) override;

  Diamond *clone() override;

private:
  point_t center_{};
  double vertical_, horizontal_;

  void doScale(double factor) override;
};

#endif
