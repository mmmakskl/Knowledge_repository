#ifndef COMPOSITESHAPE_H
#define COMPOSITESHAPE_H

#include <cstddef>
#include "shape.h"

namespace pelipeychenko {
  class CompositeShape {
  public:
    explicit CompositeShape(std::size_t size);

    CompositeShape();

    CompositeShape(const CompositeShape &instance);

    CompositeShape(CompositeShape &&instance) noexcept;

    ~CompositeShape();

    rectangle_t getFrameRect() const;

    double getArea() const;

    void scale(double factor);

    void move(double dX, double dY);

    void move(const point_t &newCenter);

    CompositeShape *clone();

    void pushBack(Shape *newShape);

    void popBack();

    pelipeychenko::Shape *at(std::size_t index) const;

    pelipeychenko::Shape *operator[](std::size_t index) const;

    bool empty() const;

    std::size_t size() const;

  private:
    std::size_t size_;
    pelipeychenko::Shape **data_;
  };
}

#endif
