#ifndef RECTANGLE_H
#define RECTANGLE_H

#include "shape.h"

class Rectangle: public pelipeychenko::Shape {
public:

  Rectangle(const point_t &leftLowerP, const point_t &rightUpperP);

  ~Rectangle() override = default;

  double getArea() const override;

  rectangle_t getFrameRect() const override;

  void move(const point_t &newCenter) override;

  void move(double dX, double dY) override;

  Rectangle *clone() override;

private:

  point_t center_;
  double width_, height_;

  void doScale(double factor) override;
};

#endif
