#include <iostream>

int main() {
  std::cout << "pelipeychenko.denis\n";
  return 0;
}
