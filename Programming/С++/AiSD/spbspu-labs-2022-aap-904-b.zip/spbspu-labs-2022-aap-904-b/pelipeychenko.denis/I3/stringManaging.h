#ifndef STRINGSTYLEC_STRINGMANAGING_H
#define STRINGSTYLEC_STRINGMANAGING_H

namespace pelipeychenko {
  void deleteDigits(char *result, const char *source);
}

#endif
