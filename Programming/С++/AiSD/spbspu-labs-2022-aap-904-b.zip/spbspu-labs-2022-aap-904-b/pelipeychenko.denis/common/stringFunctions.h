#ifndef COMMON_STRINGFUNCTIONS_H
#define COMMON_STRINGFUNCTIONS_H

#include <cstddef>
#include <iostream>

namespace pelipeychenko {
  char *inputString(std::istream &in, std::size_t &size);
};


#endif
