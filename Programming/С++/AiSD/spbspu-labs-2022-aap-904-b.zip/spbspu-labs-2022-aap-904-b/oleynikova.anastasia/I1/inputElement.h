#ifndef INPUT_ELEMENT_H
#define INPUT_ELEMENT_H

namespace oleynikova {
  int inputElement();
}

#endif
