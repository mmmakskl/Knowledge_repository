#ifndef INPUT_H
#define INPUT_H

namespace oleynikova {
  int inputElement();
}

#endif
