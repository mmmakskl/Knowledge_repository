#ifndef MAKE_STRING_H
#define MAKE_STRING_H

namespace oleynikova {
  char *makeString(char *newString, const char *string);
}

#endif
