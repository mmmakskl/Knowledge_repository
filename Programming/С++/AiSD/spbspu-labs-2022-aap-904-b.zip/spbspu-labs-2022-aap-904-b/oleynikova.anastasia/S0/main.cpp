﻿#include <iostream>

int main()
{
  std::cout << "oleynikova.anastasia\n";
  return 0;
}
