#ifndef OUTPUT_TABLE_H
#define OUTPUT_TABLE_H

#include <cstddef>

namespace oleynikova {
  void outputTable(const double &absError, const size_t &numberMax, const double &start, const double &end, const double &step);
}

#endif
