#include <iostream>

int main()
{
  std::cout << "sviridov.maxim" << std::endl;
}
