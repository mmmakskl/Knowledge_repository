#ifndef DIVISIONS_COUNT_H
#define DIVISIONS_COUNT_H

namespace chupina {
  int divisionsCount(const int &nextNum, int &prevNum, int &seqCount, int answer);
  void isInputCorrect();
}
#endif
