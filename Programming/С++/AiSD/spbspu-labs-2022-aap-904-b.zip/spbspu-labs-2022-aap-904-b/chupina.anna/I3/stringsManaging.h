#ifndef STRINGS_MANAGING_H
#define STRINGS_MANAGING_H

namespace chupina {
  char * replaceUpperToLowerCase(char * newCString, const char * cString);
}

#endif
