#include <iostream>

int main()
{
  std::cout << "chupina.anna" << std::endl;
  return 0;
}
