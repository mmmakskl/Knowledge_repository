#ifndef CSTRING_FUNCTIONS_H
#define CSTRING_FUNCTIONS_H
#include <iostream>
#include <cstddef>

namespace chupina {
  char* inputString(std::istream &in, size_t &capacity);
}

#endif
