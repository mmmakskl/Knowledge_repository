#include <iostream>

void outArray (int (&outArray)[], int n)
{
    for (int i = 0; i < n; i++)
    {
        std::cout << outArray[i] << "\n";
    }
}

int main()
{
    int OutArray[] = {1,2,3,4,5,6,7,8,9,0,1,2,3,4,5,6,7,8,9,0};
    int k = sizeof(OutArray) / sizeof(OutArray[0]);
    outArray(OutArray, k);
    return 0;
}

