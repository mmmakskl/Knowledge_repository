#ifndef POINT_HPP
#define POINT_HPP
#include <stdio.h>

class Point
{
private:
    float x_;
    float y_;
public:
    Point();
    Point(float x, float y);
    Point(const Point & ob);
//    ~Point();
    
    void setX(float x);
    void setY(float y);
    float getX() const;
    float getY() const;
    
    bool isEqual(Point A, Point B);
    float getDistance(Point A, Point B);
    Point move(Point A, float k);
    
};

#endif
