#include <iostream>
#include <cmath>
#include "Point.hpp"

bool isPointInCircle(const Point & A)
{
  float R = 4;
  if (pow(A.getX(), 2) + pow(A.getY(), 2) <= R*R)
  {
    return true;
  }
  return false;
}

Point input(std::istream & in)
{
  float x = 0;
  float y = 0;
  in >> x;
  in >> y;
  return Point(x, y);
}

void output(Point A)
{
  std::cout << A.getX() << " " << A.getY() << "\n";
}

int main()
{
  Point point;
  
  //    test
  Point A = input(std::cin);
  Point B = input(std::cin);
  output(A);
  output(B);
  std::cout << isPointInCircle(A) << "\n";
  std::cout << isPointInCircle(B) << "\n";
  std::cout << point.isEqual(A, B) << "\n";
  std::cout << point.move(A, 2).getX() << " " << point.move(A, 2).getY() << "\n";
  std::cout << point.getDistance(A, B) << "\n";
  
  //    task
  Point C(1, 1);
  Point O(0, 0);
  float min_dist = 100000;
  Point min_Point(0,0);
  
  while ((C.getX() != 0) && (C.getY() != 0))
  {
    C = input(std::cin);
    if ((C.getX() != 0) && (C.getY() != 0))
    {
      float dist = point.getDistance(C, O);
      if (dist < min_dist)
      {
        min_dist = dist;
        min_Point.setX(C.getX());
        min_Point.setY(C.getY());
      }
    }
  }
  
  std::cout << min_Point.getX() << " " << min_Point.getY() << "\n";
  
  return 0;
}
