#include "Point.hpp"
#include <cmath>

Point::Point():
x_(0.0),
y_(0.0)
{}

Point::Point(float x, float y):
x_(x),
y_(y)
{}

Point::Point(const Point & ob):
x_ (ob.x_),
y_(ob.y_)
{}

void Point::setX(float x)
{
  x_ = x;
}

void Point::setY(float y)
{
  y_ = y;
}

float Point::getX() const
{
  return x_;
}

float Point::getY() const
{
  return y_;
}

bool Point::isEqual(Point A, Point B)
{
  return ( (A.getX()== B.getX()) && (A.getY() == B.getY()) ? true : false);
}

float Point::getDistance(Point A, Point B)
{
  float dist = pow((A.getX() - B.getX()), 2) +  pow((A.getY() - B.getY()), 2);
  return pow(dist, 0.5);
}

Point Point::move(Point A, float k)
{
  return Point(A.getX() + k, A.getY() + k);
}
