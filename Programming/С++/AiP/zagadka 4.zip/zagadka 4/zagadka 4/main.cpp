//Функция, имеющая один параметр (целое число) и возвращающую число единиц в двоичной
// записи этого числа.

#include <iostream>

int count(int num)
{
    int units = 0;
    while(num > 0)
    {
        if (num % 2 == 1)
        {
            units++;
        }
        num = num/2;
    }
    return units;
}


int main() {
    int num = 0;
    std::cin >> num;
    std::cout << count(num) << "\n";
    return 0;
}
