//Напишите функцию outArray, имеющую три параметра – адрес матрицы (целые числа, встроенный массив), количество строк и количество столбцов, и выполняющую вывод всех элементов массива в поток cout. Каждую строку матрицы надо выводить с новой строки.
#include <iostream>

void outArray(const int rows, const int cols, int matrix[rows][cols])
{
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            std::cout << matrix[i][j] << " ";
        }
        std::cout << "\n";
    }
}

int main()
{
    const int rows = 4;
    const int cols = 4;
    int matrix[rows][cols];
    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            std::cin >> matrix[i][j];
        }
    }
    
    outArray(rows, cols, (*matrix)[cols]);
    
    return 0;
}
