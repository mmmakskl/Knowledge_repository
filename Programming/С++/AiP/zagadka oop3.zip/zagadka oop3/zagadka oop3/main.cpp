#include <iostream>

class Pet
{
public:
  virtual void voice(std::ostream & out) const = 0;
  virtual void name(std::ostream & out) const = 0;
  std::string name_;
};

class Cat : public virtual Pet
{
public:
  Cat(std::string name):
  name_(name)
  {}
  virtual void voice(std::ostream & out) const
  {
    out << "meow";
  }
  virtual void name(std::ostream & out) const
  {
    out << name_;
  }
private:
  std::string name_;
};

class Dog : public virtual Pet
{
public:
  Dog(std::string name):
  name_(name)
  {}
  virtual void voice(std::ostream & out) const
  {
    out << "bark";
  }
  virtual void name(std::ostream & out) const
  {
    out << name_;
  }
private:
  std::string name_;
};

class FamilyPets
{
public:
  FamilyPets(int maxNum):
  maxNum_(maxNum),
  realNum_(0)
  {
    pets_ = new const Pet*[maxNum];
  }
  
  void name() const
  {
    for (int i = 0; i < realNum_; i++)
    {
      pets_[i]->name(std::cout << "\n");
    }
  }
  void voice() const
  {
    for (int i = 0; i < realNum_; i++)
    {
      pets_[i]->voice(std::cout << "\n");
    }
  }
  
  void operator+(const Pet * newPet)
  {
    if (realNum_ < maxNum_)
    {
      pets_[realNum_] = newPet;
      realNum_++;
    }
    else
    {
      std::cout << "Family is full!";
    }
  }
  
  friend std::ostream & operator<<(std::ostream & out, const FamilyPets & family)
  {
    out << "names of pets in the family:";
    family.name();
    out << "\n";
    out << "voices of pets in the family:";
    family.voice();
    out << "\n";
    return out;
  }

private:
  int maxNum_;
  int realNum_;
  const Pet ** pets_;
};

int main()
{
  Pet * pCat;
  Pet * pDog;
  Cat cat("Pushok");
  Dog dog("Bobik");
  
  pCat = &cat;
  pDog = &dog;
  
  cat.name(std::cout << "\n");
  cat.voice(std::cout << "\n");
  
  dog.name(std::cout << "\n");
  dog.voice(std::cout << "\n");
  
  pCat->name(std::cout << "\n");
  pCat->voice(std::cout << "\n");
  
  pDog->name(std::cout << "\n");
  pDog->voice(std::cout << "\n");
  
  Pet * pPet;
  pPet = &cat;
  pPet->name(std::cout << "\n");
  pPet->voice(std::cout << "\n");
  
  pPet = &dog;
  pPet->name(std::cout << "\n");
  pPet->voice(std::cout << "\n");
  
  std::cout << "\n";
  
  FamilyPets family(5);
  
  family + &cat;
  family + &dog;
  
  family.name();
  family.voice();
  
  std::cout << "\n";
  
  std::cout << family;
  
  return 0;
}
