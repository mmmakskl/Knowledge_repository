#ifndef TEST_HPP
#define TEST_HPP
#include <stdio.h>

void testPoint();

#endif
