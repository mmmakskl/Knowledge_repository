#ifndef POINT_HPP
#define POINT_HPP
#include <stdio.h>
#include <fstream>

class Point
{
private:
    float x_;
    float y_;
public:
    Point();
    Point(float x, float y);
    Point(const Point & ob);
    
    Point operator=(const Point & right);
    bool operator==(const Point & right) const;
    bool operator<(const Point & right) const;
    bool operator>=(const Point & right) const;
    Point operator+(float k) const;
    void operator+=(float k);
    void operator+=(Point & right);
    friend std::ostream& operator<<(std::ostream& out, const Point & ob);
    friend std::istream& operator>>(std::istream& in, Point & ob);
};

#endif
