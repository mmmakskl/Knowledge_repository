#include <iostream>
#include "Point.hpp"
#include "test.hpp"

const Point GLOBAL_POINT(1,1);
int main() {
  setlocale(LC_ALL, "rus");
  testPoint();
  return 0;
}
