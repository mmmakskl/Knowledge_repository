#include "Point.hpp"
#include <fstream>

Point::Point():
x_(0.0),
y_(0.0)
{}

Point::Point(float x, float y):
x_(x),
y_(y)
{}

Point::Point(const Point & ob):
x_ (ob.x_),
y_(ob.y_)
{}

Point Point::operator=(const Point & right)
{
  x_ = right.x_;
  y_ = right.y_;
  return *this;
}

bool Point::operator==(const Point & right) const
{
  return ((x_ == right.x_) && (y_ == right.y_));
}

bool Point::operator<(const Point & right) const
{
  return ( (x_ * x_ + y_ * y_) < (right.x_ * right.x_ + right.y_ * right.y_) );
}

bool Point::operator>=(const Point & right) const
{
  return ( (x_ * x_ + y_ * y_) >= (right.x_ * right.x_ + right.y_ * right.y_) );
}

Point Point::operator+(float k) const
{
  return Point(x_ + k, y_ + k);
}

void Point::operator+=(float k)
{
  x_ += k;
  y_ += k;
}

void Point::operator+=(Point & right)
{
  x_ += right.x_;
  y_ += right.y_;
}

std::ostream& operator<<(std::ostream& out, const Point& ob)
{
  return (out << "x=" << ob.x_ << " y=" << ob.y_);
}

std::istream& operator>>(std::istream& in, Point & ob)
{
  return (in >> ob.x_ >> ob.y_);
}
