//
//  main.cpp
//  zagadka 2
//
//  Created by Анна Резникова on 22.10.2023.
//

//1.3
/*
#include <iostream>

int main() {
  
  int x1 = 0;
  int y1 = 0;
  int x2 = 0;
  int y2 = 0;
  
  std::cin >> x1 >> y1 >> x2 >> y2;
  
  if (abs(x2-x1) == abs(y2-y1))
  {
    std::cout << "bishop beats the figure\n";
  }
  
  else
  {
    std::cout << "bishop doesn't beat figure\n";
  }
  
  return 0;
}
*/

//2.3
//#include <iostream>
//
//int main()
//{
//
//    int a = 0;
//    int b = 0;
//    int c = 0;
//
//    std::cin >> a >> b >> c;
//
//    if (a == b == c)
//    {
//        std::cout << "3\n";
//    } else if ((a == b) || (b == c) || (c == a)) {
//        std::cout << "2\n";
//    } else {
//        std::cout << "нет совпадений\n";
//    }
//
//    return 0;
//}

#include <iostream>
int main()
{
    size_t i = 18446744073709551615;
}

