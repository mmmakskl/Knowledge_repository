//По данному числу N распечатайте все целые степени двойки, не превосходящие N, в
// порядке возрастания. Операцией возведения в степень пользоваться нельзя!
//


// 1 задание


//#include <iostream>
//
//int main() {
//
//  int N = 0;
//  std::cin >> N;
//  if (!std::cin)
//  {
//    std::cout << "N задано не целым числом\n";
//    return 1;
//  }
//  int ans = 1;
//  for (int i = 0; i <= N; i++)
//  {
//    std::cout << ans << "\n";
//    ans = ans * 2;
//  }
//  return 0;
//}


// 2 задание
//Среднее арифметическое введенных положительных чисел
//
#include <iostream>

int main() {
  int number = 0;
  int sumPositive = 0;
  int countPositive = 0;
  do
  {
    std::cin >> number;
    if (!std::cin)
    {
      std::cout << "задано не целое число\n";
      return 1;
    }
    if (number > 0)
    {
      sumPositive = sumPositive + number;
      countPositive++;
    }

  }
  while (number != 0);
  std::cout << (sumPositive / countPositive) << "\n";
  return 0;
}
